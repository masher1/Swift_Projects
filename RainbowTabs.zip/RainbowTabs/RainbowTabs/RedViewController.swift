//
//  ViewController.swift
//  RainbowTabs
//
//  Created by Malkiel Asher on 3/25/20.
//  Copyright © 2020 Malkiel Asher. All rights reserved.
//

import UIKit

class RedViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //tabBarItem.badgeValue = "!"
        //tabBarItem.badgeValue = nil
    }


}

