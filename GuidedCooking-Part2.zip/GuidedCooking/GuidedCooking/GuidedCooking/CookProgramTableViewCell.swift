//
//  CookProgramTableViewCell.swift
//  GuidedCooking
//
//  Created by Dean Stirrat on 2/26/20.
//  Copyright © 2020 Dean Stirrat. All rights reserved.
//

import UIKit

class CookProgramTableViewCell: UITableViewCell {
    
    //MARK Properties
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var photoImageView: UIImageView!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
