//
//  SkillLevel.swift
//  GuidedCooking
//
//  Created by Malkiel Asher on 3/20/20.
//  Copyright © 2020 Dean Stirrat. All rights reserved.
//

import Foundation

enum SkillLevel {
    case easy, medium, simple, difficult
}
