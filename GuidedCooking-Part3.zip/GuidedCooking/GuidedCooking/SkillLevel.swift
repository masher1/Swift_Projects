//
//  SkillLevel.swift
//  GuidedCooking
//
//  Created by Kathleen Monje on 3/11/20.
//  Copyright © 2020 Dean Stirrat. All rights reserved.
//

import Foundation

enum SkillLevel {
    case easy, medium, simple, difficult
}
