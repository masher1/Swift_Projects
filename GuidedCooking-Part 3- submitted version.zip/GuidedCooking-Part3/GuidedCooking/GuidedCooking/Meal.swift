//
//  Meal.swift
//  GuidedCooking
//
//  Created by Malkiel Asher on 3/20/20.
//  Copyright © 2020 Dean Stirrat. All rights reserved.
//

import Foundation

enum Meal {
    case side, dessert, lunch, dinner, snack, appetizer, brunch, breakfast, beverage
}
