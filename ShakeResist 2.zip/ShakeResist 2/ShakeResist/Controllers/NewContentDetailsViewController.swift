//
//  NewContentDetailsViewController.swift
//  ShakeResist
//
//  Created by Malkiel Asher on 5/6/20.
//  Copyright © 2020 Malkiel Asher. All rights reserved.
//

import UIKit

class NewContentDetailsViewController: UIViewController {


    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var contentTextView: UITextView!
    
    var submission:Submission?
    
    @IBOutlet weak var saveButton: UIBarButtonItem!
    
    @IBAction func textEditingChanged(_ sender: UITextField) {
        updateSaveButtonState()
    }
    
    func updateSaveButtonState(){
        let title = titleTextField.text ?? ""
        let content = contentTextView.text ?? ""

        saveButton.isEnabled = !title.isEmpty && !content.isEmpty
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
            
        if let submission = submission {
            titleTextField.text = submission.title
            contentTextView.text = submission.content

        }
        updateSaveButtonState()
    }
    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        guard segue.identifier == "saveUnwind" else {return}
        
        let title = titleTextField.text ?? ""
        let content = contentTextView.text ?? ""

        submission = Submission(title: title, content: content)
    }

}
