//
//  Food.swift
//  MealTracker
//
//  Created by Malkiel Asher on 4/9/20.
//  Copyright © 2020 Malkiel Asher. All rights reserved.
//

import Foundation

struct Food {
    var name:String
    var description:String
}
