//
//  CookProgramTableViewController.swift
//  GuidedCooking
//
//  Created by Dean Stirrat on 2/26/20.
//  Copyright © 2020 Dean Stirrat. All rights reserved.
//

import UIKit

class CookProgramTableViewController: UITableViewController {

    
    
    //MARK Properties
    
    var cookPrograms = [CookProgram]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Load the sample data.
        loadSampleCookPrograms()
    }

    
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return cookPrograms.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Table view cells are reused and should be dequeued using a cell identifier.
        let cellIdentifier = "CookProgramTableViewCell"
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? CookProgramTableViewCell  else {
            fatalError("The dequeued cell is not an instance of CookProgramTableViewCell.")
        }

        // Fetches the appropriate cook program for the data source layout.
        let cookProgram = cookPrograms[indexPath.row]
        
        cell.nameLabel.text = cookProgram.name
        cell.descriptionLabel.text = cookProgram.description
        cell.photoImageView.image = cookProgram.photo


        return cell
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
//Mark: Private Methods
    
    private func loadSampleCookPrograms() {
        let photo1 = UIImage(named: "CookProgram1")
        let photo2 = UIImage(named: "CookProgram2")
        let photo3 = UIImage(named: "CookProgram3")
    
        
        guard let cookProgram1 = CookProgram(name: "CookProgram1", photo: photo1, description: "Creates a crust that's dense and chewy, but tender and easy to bite through.") else {
            fatalError("Unable to instantiate cookProgram1")
        }
        
        guard let cookProgram2 = CookProgram(name: "CookProgram2", photo: photo2, description: "Creates a crust that's dense and chewy, but tender and easy to bite through.") else {
            fatalError("Unable to instantiate cookProgram2")
        }
         
        guard let cookProgram3 = CookProgram(name: "CookProgram3", photo: photo3, description: "Perfect crisp crackly top, super fudgy centre, chewy or gooey in all the right places, studded with melted chunks of chocolate.") else {
            fatalError("Unable to instantiate cookProgram3")
        }
        cookPrograms += [cookProgram1, cookProgram2, cookProgram3]
        
    }
    
    
}
