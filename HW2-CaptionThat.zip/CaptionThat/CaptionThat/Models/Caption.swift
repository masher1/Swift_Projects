//
//  Caption.swift
//  CaptionThat
//
//  Created by Malkiel Asher on 2/14/20.
//  Copyright © 2020 Malkiel Asher. All rights reserved.
//

import Foundation

struct Caption{
    
}
