//
//  CookProgram.swift
//  GuidedCooking
//
//  Created by Dean Stirrat on 2/25/20.
//  Copyright © 2020 Dean Stirrat. All rights reserved.
//

import UIKit

class CookProgram: CustomStringConvertible, Equatable, Comparable {
    
    // MARK: Properties

    let name: String
    let id: UUID
    let photo: UIImage?
    let programDescription: String?
    let mealType: Meal
    let skillLevel: SkillLevel
    
    // MARK: Initialization

    init?(name: String, photo: UIImage?, programDescription: String?, mealType: Meal, skillLevel: SkillLevel) {
        
        //check for null input for name value
        guard !name.isEmpty else {
            return nil
        }
        //check for emoji input for name value during initalization
        // 1. isolate first char in string then call let c = firstCharInString then c.isEmoji()
        guard !name.containsEmoji else {
            return nil
        }
        
        // Initialize the stored properties
        self.name = name
        self.id = UUID()
        self.photo = photo
        self.programDescription = programDescription
        self.mealType = mealType
        self.skillLevel = skillLevel
    }
    
    // MARK: CustomStringConvertible

    var description: String {
        return "CookProgram(name: \(name), id: \(id), description: \(programDescription))"
    }
    
    // MARK: Equatable

    static func == (lhs: CookProgram, rhs: CookProgram) -> Bool {
        return lhs.name == rhs.name
            && lhs.photo == rhs.photo
            && lhs.programDescription == rhs.programDescription
    }
    
    // MARK: Comparable

    static func < (lhs: CookProgram, rhs: CookProgram) -> Bool {
        return lhs.name < rhs.name
    }
}

extension Character {
    /// A simple emoji is one scalar and presented to the user as an Emoji
    var isSimpleEmoji: Bool {
        guard let firstProperties = unicodeScalars.first?.properties else {
            return false
        }
        return unicodeScalars.count == 1 &&
            (firstProperties.isEmojiPresentation ||
                firstProperties.generalCategory == .otherSymbol)
    }

    /// Checks if the scalars will be merged into an emoji
    var isCombinedIntoEmoji: Bool {
        return (unicodeScalars.count > 1 &&
               unicodeScalars.contains { $0.properties.isJoinControl || $0.properties.isVariationSelector })
            || unicodeScalars.allSatisfy({ $0.properties.isEmojiPresentation })
    }

    var isEmoji: Bool {
        return isSimpleEmoji || isCombinedIntoEmoji
    }
}

extension String {
    var isSingleEmoji: Bool {
        return count == 1 && containsEmoji
    }

    var containsEmoji: Bool {
        return contains { $0.isEmoji }
    }

    var containsOnlyEmoji: Bool {
        return !isEmpty && !contains { !$0.isEmoji }
    }

    var emojiString: String {
        return emojis.map { String($0) }.reduce("", +)
    }

    var emojis: [Character] {
        return filter { $0.isEmoji }
    }

    var emojiScalars: [UnicodeScalar] {
        return filter{ $0.isEmoji }.flatMap { $0.unicodeScalars }
    }
}

