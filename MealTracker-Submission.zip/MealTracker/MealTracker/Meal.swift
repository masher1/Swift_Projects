//
//  Meal.swift
//  MealTracker
//
//  Created by Malkiel Asher on 4/9/20.
//  Copyright © 2020 Malkiel Asher. All rights reserved.
//

import Foundation

struct Meal {
    var name:String
    var foods:[Food]
    
}
