//
//  Ingredient.swift
//  GuidedCooking
//
//  Created by Kathleen Monje on 3/4/20.
//  Copyright © 2020 Dean Stirrat. All rights reserved.
//

import UIKit

struct Ingredient: Codable {

    // MARK: Properties
    let name: String
    
}
