//
//  CookProgramDetailsViewController.swift
//  GuidedCooking
//
//  Created by Malkiel Asher on 3/2/20.
//  Copyright © 2020 Dean Stirrat. All rights reserved.
//

import UIKit

class CookProgramDetailsViewController: UIViewController {

    // MARK: Properties
    
    var cookProgram: CookProgram?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let string = "Hello, world!"
        print(string)

        let number = 42
        print(number)
         
        let boolean = false
        print(boolean)
        
        print(cookProgram)
        
        // Set up views if viewing an existing CookProgram.
        if let cookProgram = cookProgram {
            navigationItem.title = cookProgram.name
            detailsTitle.text = cookProgram.name
            detailsDescription.text = cookProgram.programDescription
            detailsImage.image = cookProgram.photo
            
        }
    }
    
    @IBOutlet weak var detailsImage: UIImageView!
    @IBOutlet weak var detailsTitle: UILabel!
    @IBOutlet weak var detailsDescription: UILabel!
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
