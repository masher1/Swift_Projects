//
//  GuidedCookingTests.swift
//  GuidedCookingTests
//
//  Created by Dean Stirrat on 2/25/20.
//  Copyright © 2020 Dean Stirrat. All rights reserved.
//

import XCTest
@testable import GuidedCooking

class GuidedCookingTests: XCTestCase {

    //MARK: 'CookProgram Tests'
    
    //Stirng name
    func testCookProgramInitilizationSucceeds(){
        let stringNameCookProgram = CookProgram.init(name: "Cheeseburger", photo: nil, description: nil)
        XCTAssertNotNil(stringNameCookProgram)
    }
    
    //String is empty
    func testCookProgramInitilizationFails(){
        let emptyStringCookProgram = CookProgram.init(name: "", photo: nil, description: nil)
        XCTAssertNil(emptyStringCookProgram)
    }
    
    // Confirm that the `CookProgram` initializer returns nil when passed an emoji wrapped in a string as the name
    func testCookProgramInitializationWithEmojiFails() {
        let emojiCookProgram = CookProgram.init(name: "🍔", photo: nil, description: nil)
        XCTAssertNil(emojiCookProgram)
    }
}
