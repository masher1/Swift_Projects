//
//  Meal.swift
//  GuidedCooking
//
//  Created by Kathleen Monje on 3/11/20.
//  Copyright © 2020 Dean Stirrat. All rights reserved.
//

import Foundation

enum Meal {
    case side, dessert, lunch, dinner, snack, appetizer, brunch, breakfast, beverage
}
