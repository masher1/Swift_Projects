//
//  GuidedCookingTests.swift
//  GuidedCookingTests
//
//  Created by Dean Stirrat on 2/25/20.
//  Copyright © 2020 Dean Stirrat. All rights reserved.
//

import XCTest
@testable import GuidedCooking

class GuidedCookingTests: XCTestCase {

    // MARK: 'CookProgram Tests'
    
    //String name
    func testCookProgramInitilizationSucceeds(){
        let stringNameCookProgram = CookProgram.init(
            name: "Cheeseburger",
            photo: nil,
            programDescription: nil,
            mealType: .appetizer,
            skillLevel: .medium)
        XCTAssertNotNil(stringNameCookProgram)
    }
    
    //String is empty
    func testCookProgramInitilizationFails(){
        let emptyStringCookProgram = CookProgram.init(
            name: "",
            photo: nil,
            programDescription: nil,
            mealType: .dessert,
            skillLevel: .simple)
        XCTAssertNil(emptyStringCookProgram)
    }
    
    // Confirm that the `CookProgram` initializer returns nil when passed an emoji wrapped in a string as the name
    func testCookProgramInitializationWithEmojiFails() {
        let emojiCookProgram = CookProgram.init(
            name: "🍔",
            photo: nil,
            programDescription: nil,
            mealType: .appetizer,
            skillLevel: .medium)
        XCTAssertNil(emojiCookProgram)
    }
    
    // Conffirm that the `Equatable` protocol is properly implemented in for CookProgram
    func testCookProgramCorrectlyConformsToEquatable() {
        let photo1 = UIImage(named: "CookProgram1")
        let photo2 = UIImage(named: "CookProgram1")
        
        guard let cookProgram1 = CookProgram(
            name: "Pizza",
            photo: photo1,
            programDescription: "Creates a crust that's dense and chewy, but tender and easy to bite through.",
            mealType: .dinner,
            skillLevel: .medium)
            else { fatalError("Unable to instantiate cookProgram1")
        }
        
        guard let cookProgram2 = CookProgram(
            name: "Pizza",
            photo: photo2,
            programDescription: "Creates a crust that's dense and chewy, but tender and easy to bite through.",
            mealType: .dinner,
            skillLevel: .medium)
            else { fatalError("Unable to instantiate cookProgram2")
        }
        
        XCTAssertEqual(cookProgram1, cookProgram2)
    }

    // Confirm that two `CookProgram`s with different names or  photo , or `programDescription`s are deemed inequal
    func testKnownDifferentCookPrograms() {
        // Sugar cookie
        let cookieProgram1 = CookProgram.init(
            name: "Cookie",
            photo: UIImage(named:"chocolate-chip-cookie"),
            programDescription: "Crisp edges, chewy middles.",
            mealType: .snack,
            skillLevel: .simple)

        // Chcoolate chip cookie
        let cookieProgram2 = CookProgram.init(
            name: "Cookie",
            photo: UIImage(named:"sugar-cookie"),
            programDescription: "Glistens with sugar crystals, and packed with a sweet vanilla-wheat flavor.",
            mealType: .snack,
            skillLevel: .medium)

        XCTAssertNotEqual(cookieProgram1, cookieProgram2)
    }
}
